# app.py
from fastapi import FastAPI
from fastapi.responses import RedirectResponse

app = FastAPI()

# Home route - returns API key
@app.get("/")
def read_root():
    return {"message": "AIzaSyALieYStWm_bxzCAC39H0IlB3LdE2Xguxc"}

# Basic redirect - this will immediately redirect to Google
@app.get("/google")
def redirect_to_google():
    return RedirectResponse(url="https://www.google.com")

# Gemini redirect
@app.get("/gemini")
def redirect_to_gemini():
   
# Example redirect with dynamic URL based on parameter
@app.get("/goto/{site}")
def dynamic_redirect(site: str):
    sites = {
         "gemini": "https://gemini.google.com",

    }
    if site in sites:
        return RedirectResponse(url=sites[site])
    else:
        return {"error": f"No redirect configured for {site}"}