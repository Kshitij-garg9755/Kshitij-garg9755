async function processAndReply(inputText) {
  displayTyping();

  try {
    const response = await fetch('https://weather.com/en-IN/weather/today/l/632923eeaec68d6e63daf96cf00963362c2fb426a144a1f499b5b73ab3ee97d9', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // 'Authorization': 'Bearer YOUR_API_KEY', // agar zarurat ho
      },

      
      body: JSON.stringify({
        query: inputText
      })
    });

    const data = await response.json();
    removeTyping();
    displayMessage(data.reply || "No reply received from API.", 'bot');

  } catch (error) {
    removeTyping();
    displayMessage("❌ Error: API call failed.", 'bot');
    console.error(error);
  }
}
